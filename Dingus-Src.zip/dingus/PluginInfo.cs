﻿namespace dingus
{
    internal class PluginInfo
    {
        public const string GUID = "gizmo.lucy.dingus";
        public const string Name = "dingus";
        public const string Version = "1.0.0";
    }
}
